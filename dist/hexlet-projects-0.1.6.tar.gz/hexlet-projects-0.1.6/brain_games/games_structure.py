#!/usr/bin/env python3


"""All Brain-games structure"""


import prompt


rounds_num = 3


def hello():
    print("Welcome to the Brain Games!")
    name = prompt.string("May I have your name? ")
    print("Hello, " + name + "!")


def structure():
    hello()
    for i in range(rounds_num):
    question, correct_answer = game.round()
    print(f"Question: {str(question)}")
    answer = prompt.string("Your answer: ")
    if answer == correct_answer:
        print("Correct!")
    else:
        print(
            f"'{answer}' is wrong answer ;(. "
            f"Correct answer was '{correct_answer}'\n"
            f"Let's try again, {user_name}!"
        )
        return
    print("Congratulations, " + name + "!")
