#!usr/bin/env python3


from hello_module import hello_module


def main():
    hello_module.hello()


if __name__ == '__main__':
    main()
